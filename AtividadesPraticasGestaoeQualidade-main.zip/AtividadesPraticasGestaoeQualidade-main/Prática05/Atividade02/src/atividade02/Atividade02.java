package atividade02;

public class Atividade02 {

    public static void main(String[] args) {
        int soma = 0;

        for (int i = 0; i <= 20; i++) {

                soma=soma+i;
            }
                System.out.println("A soma dos numeros é: " + soma);

        }

    }



