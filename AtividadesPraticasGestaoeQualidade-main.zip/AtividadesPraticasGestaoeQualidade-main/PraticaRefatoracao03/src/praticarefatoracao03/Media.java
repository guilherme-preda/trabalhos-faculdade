
package praticarefatoracao03;


public class Media {
        
        
    public double calcularMedia(double soma){
        return soma/4;
    }
    
    
    
    
    
}
