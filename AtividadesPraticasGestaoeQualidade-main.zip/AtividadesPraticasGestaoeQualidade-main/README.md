# AtividadesPraticasGestaoeQualidade
Atividades práticas realizadas por: Gabriel Asevedo de Amorim, Guilherme de Almeida Oliveira, Gabriel Augusto Ferreira Maia, Guilherme Asevedo de Amorim na UC de Gestão e Qualidade de Software
